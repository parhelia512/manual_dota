// DecodeABC.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <vector>
#include <iostream>
#include <string>
#include <fstream>

typedef std::vector<char> DataBuffer;
typedef std::vector<std::string> FileList;


namespace detail
{
	static long long		dataSize	= 0;
	static long long		curPos		= 0;
	static unsigned char*	pBuf		= NULL;

	static void setDataSize(long long sz) { dataSize = sz; }

	static voidpf ZCALLBACK fopen_stream_func(voidpf opaque, const char* data, int mode)
	{
		pBuf = (unsigned char*)data;
		return (voidpf)data;
	}

	static uLong ZCALLBACK fread_stream_func(voidpf opaque, voidpf stream, void* buf, uLong size)
	{
		uLong readS = size;
		if (curPos + size>dataSize)
		{
			readS = size - ((curPos + size) - dataSize);
		}
		curPos += readS;
		memcpy(buf, pBuf, readS);
		pBuf += readS;
		return readS;
	}

	static uLong ZCALLBACK fwrite_stream_func(voidpf opaque, voidpf stream, const void* buf, uLong size)
	{
		uLong ret = -1;
		return ret;
	}

	static long ZCALLBACK ftell_stream_func(voidpf opaque, voidpf stream)
	{
		long ret = 0;
		unsigned char* temp = (unsigned char*)stream;
		ret = pBuf - temp;
		return ret;
	}

	static long ZCALLBACK fseek_stream_func(voidpf  opaque, voidpf stream, uLong offset, int origin)
	{
		long ret = 0;
		unsigned char* temp = (unsigned char*)stream;
		switch (origin)
		{
		case ZLIB_FILEFUNC_SEEK_CUR:
			pBuf = pBuf + offset;
			curPos += offset;
			break;
		case ZLIB_FILEFUNC_SEEK_END:
			pBuf = temp + dataSize;
			pBuf += offset;
			curPos = (dataSize)+offset;
			break;
		case ZLIB_FILEFUNC_SEEK_SET:
			pBuf = temp;
			pBuf += offset;
			curPos = offset;
			break;
		default: return -1;
		}
		return ret;
	}

	static int ZCALLBACK fclose_stream_func(voidpf opaque, voidpf stream)
	{
		int ret = 0;
		pBuf = (unsigned char*)stream;
		return ret;
	}

	static int ZCALLBACK ferror_stream_func(voidpf opaque, voidpf stream)
	{
		int ret = 0;
		return ret;
	}

	void efill_fopen_filefunc(zlib_filefunc_def* pzlib_filefunc_def)
	{
		pzlib_filefunc_def->zopen_file = fopen_stream_func;
		pzlib_filefunc_def->zread_file = fread_stream_func;
		pzlib_filefunc_def->zwrite_file = fwrite_stream_func;
		pzlib_filefunc_def->ztell_file = ftell_stream_func;
		pzlib_filefunc_def->zseek_file = fseek_stream_func;
		pzlib_filefunc_def->zclose_file = fclose_stream_func;
		pzlib_filefunc_def->zerror_file = ferror_stream_func;
		pzlib_filefunc_def->opaque = NULL;
	}
}


static void decode(const DataBuffer& data, const std::size_t data_size,
	const DataBuffer& name, const std::size_t name_size,
	DataBuffer& out)
{
	const int primes[] = { 0x2717, 0x2719, 0x2735, 0x2737, 0x274d, 0x2753 };

	int prime(0);
	for (auto i : primes)
	{
		if (data_size % i)
		{
			prime = i;
			break;
		}
	}

	//std::cout << "prime : " << prime << std::endl;
	//std::cout << "data_size : " << data_size << std::endl;

	int name_index(0);
	for (int i = 0; i < int(data_size); ++i)
	{
		unsigned int index = prime * i;

		unsigned char r2 = data[i];
		unsigned char r3 = name[name_index];

		unsigned long long A = (0LL << 32) + index;
		unsigned long long B = (0LL << 32) + data_size;

		unsigned long long mod = A % B;

		unsigned int pos = unsigned int(mod & 0xFFFFFFFF);

		out[pos] = r2 ^ r3;

		name_index = (name_index + 1) % name_size;
	}
}

bool unzip(const std::string& strInFilePath, TCHAR* szFileName, const DataBuffer& in_buffer)
{
	zlib_filefunc_def pzlib_filefunc32_def;
	detail::efill_fopen_filefunc(&pzlib_filefunc32_def);
	detail::setDataSize(in_buffer.size());

	unzFile pFile = unzOpen2((const char*)&in_buffer[0], &pzlib_filefunc32_def);
	assert(pFile);
	if (pFile == NULL)
	{
		return false;
	}

	unz_global_info gi;
	int result = unzGetGlobalInfo(pFile, &gi);
	if (result != UNZ_OK)
	{
		throw _T("�ļ�����");
		return false;
	}

	std::string strOutFileName = strInFilePath;
	strOutFileName = strInFilePath.substr(0, strInFilePath.size() - 4);

	unz_file_info file_info;
	static TCHAR szFilePath[260] = _T("data");
	result = unzGetCurrentFileInfo(pFile, &file_info, szFilePath, sizeof(szFilePath), NULL, 0, NULL, 0);
	if (result != UNZ_OK)
	{
		throw _T("�ļ�����");
		return false;
	}

	//���ļ�
	static TCHAR szPassword[512];
	_stprintf_s(szPassword, _T("cocos2d: ERROR: Invalid filename %s"), szFileName);
	result = unzOpenCurrentFilePassword(pFile, szPassword);
	if (result != UNZ_OK)
	{
		throw _T("�ļ�����");
		return false;
	}

	static DataBuffer unzip_buffer;
	unzip_buffer.resize(file_info.uncompressed_size);

	//��ȡ����
	int size = unzReadCurrentFile(pFile, &unzip_buffer[0], file_info.uncompressed_size);

	//�رյ�ǰ�ļ�
	unzCloseCurrentFile(pFile);
	pFile = NULL;

	strOutFileName += _T(".luac");
	HANDLE hOutFile = CreateFile(strOutFileName.c_str(),
		GENERIC_WRITE, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
	DWORD dwWritenSize = 0;
	WriteFile(hOutFile, &unzip_buffer[0], unzip_buffer.size(), &dwWritenSize, NULL);
	CloseHandle(hOutFile);

	return true;
}

bool DecodeOneFile(const std::string& strInFilePath)
{
	// ��ȡ�ļ�
	HANDLE hInFile = CreateFile(strInFilePath.c_str(),
		GENERIC_READ, 0, 0, OPEN_EXISTING, 0, 0);
	if (hInFile == INVALID_HANDLE_VALUE)
	{
		return false;
	}
	DWORD fileSize = GetFileSize(hInFile, 0);
	if (fileSize == 0)
	{
		CloseHandle(hInFile);
		return false;
	}

	static TCHAR szDrv[_MAX_DRIVE], szDir[_MAX_DIR], szFile[_MAX_FNAME], szExt[_MAX_EXT];
	_tsplitpath_s(strInFilePath.c_str(), szDrv, szDir, szFile, szExt);

	if (strcmp(szExt, _T(".abc")) != 0)
	{
		return false;
	}

	std::string strName = szFile;
	strName += szExt;

	// ��ʼ������
	static DataBuffer in_buffer;
	static DataBuffer out_buffer;
	static DataBuffer name_buffer;
	in_buffer.resize(fileSize);
	out_buffer.resize(fileSize);
	name_buffer.resize(strName.size());
	memcpy(&name_buffer[0], strName.c_str(), strName.size());

	// ��ȡ�ļ�
	DWORD dwReadedSize = 0;
	if (ReadFile(hInFile, &in_buffer[0], fileSize, &dwReadedSize, NULL) == false)
	{
		CloseHandle(hInFile);
		return false;
	}
	CloseHandle(hInFile);

	// ������
	decode(in_buffer, fileSize,
		name_buffer, name_buffer.size(),
		out_buffer);


	//std::string strOutFileName = strInFilePath;
	//strOutFileName = strInFilePath.substr(0, strInFilePath.size() - 4);
	//strOutFileName += _T(".zip");
	//HANDLE hOutFile = CreateFile(strOutFileName.c_str(),
	//	GENERIC_WRITE, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, 0);
	//DWORD dwWritenSize = 0;
	//WriteFile(hOutFile, &out_buffer[0], out_buffer.size(), &dwWritenSize, NULL);
	//CloseHandle(hOutFile);
	//return true;

	// ��ѹ��
	unzip(strInFilePath, szFile, out_buffer);

	return true;
}

TCHAR* GetCurrentPath()
{
	static TCHAR strCurPath[MAX_PATH];
	GetModuleFileName(NULL, strCurPath, MAX_PATH);
	TCHAR* p = strCurPath;
	while (strchr(p, '\\'))
	{
		p = strchr(p, '\\');
		p++;
	}
	--p;
	*p = '\0';
	return strCurPath;
}

//�����ļ��к���
void TraverseFolder(LPCTSTR lpPath, FileList& arrFiles)
{
	TCHAR szFind[MAX_PATH] = { _T("\0") };
	WIN32_FIND_DATA findFileData;
	BOOL bRet;

	_tcscpy_s(szFind, MAX_PATH, lpPath);
	_tcscat_s(szFind, _T("\\*.*"));     //����һ��Ҫָ��ͨ�������Ȼ�����ȡ�����ļ���Ŀ¼

	HANDLE hFind = ::FindFirstFile(szFind, &findFileData);
	if (INVALID_HANDLE_VALUE == hFind)
	{
		return;
	}

	//�����ļ���
	while (TRUE)
	{
		if (findFileData.cFileName[0] != _T('.'))
		{
			//���ǵ�ǰ·�����߸�Ŀ¼�Ŀ�ݷ�ʽ
			//_tprintf(_T("%s\\%s\n"), lpPath, findFileData.cFileName);
			if (findFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			{
				//����һ����ͨĿ¼
				//������һ����Ҫɨ����ļ���·��
				_tcscpy_s(szFind, MAX_PATH, lpPath);
				_tcscat_s(szFind, _T("\\"));
				_tcscat_s(szFind, findFileData.cFileName);
				//������Ŀ¼
				TraverseFolder(szFind, arrFiles);
			}
			else
			{
				std::string strPath = lpPath;
				strPath += _T("\\");
				strPath += findFileData.cFileName;
				arrFiles.push_back(strPath);
			}
		}
		//����ǵ�ǰ·�����߸�Ŀ¼�Ŀ�ݷ�ʽ����������ͨĿ¼����Ѱ����һ��Ŀ¼�����ļ�
		bRet = ::FindNextFile(hFind, &findFileData);
		if (!bRet)
		{
			//��������ʧ��
			//cout << "FindNextFile failed, error code: " 
			//  << GetLastError() << endl;
			break;
		}
	}

	::FindClose(hFind);
}

int _tmain(int argc, _TCHAR* argv[])
{
	FileList arrFiles;
	TraverseFolder(GetCurrentPath(), arrFiles);
	FileList::const_iterator iter = arrFiles.begin();
	FileList::const_iterator iEnd = arrFiles.end();
	for (;iter!=iEnd; ++iter)
	{
		const std::string& strPath = *iter;
		DecodeOneFile(strPath);
		_tprintf(_T("%s\n"), strPath.c_str());
	}

	//std::string strInFilePath(_T("errorinfo.abc"));
	//DecodeOneFile(strInFilePath);

	system("pause");
	return 0;
}

